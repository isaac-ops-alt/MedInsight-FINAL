from django.contrib import admin
from django.contrib.auth.models import User

# Register the built-in User model with the admin panel
# admin.site.register(User)
