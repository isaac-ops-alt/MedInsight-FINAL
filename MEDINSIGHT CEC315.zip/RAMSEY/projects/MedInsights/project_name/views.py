from django.shortcuts import render
from django.contrib.auth.decorators import login_required
import os
import requests
from django.http import JsonResponse
from django.conf import settings


def home(request):
    return render(request, 'index.html')  # Render 'index.html' from the 'template' folder
# def login_view(request):
#     return render(request, 'login.html')

# def register_view(request):
#     return render(request, 'signup.html')

@login_required
def UI(request):
    return render(request, 'MedInsight_UI.html')

def chat_with_ai(request):
    if request.method == "POST":
        user_message = request.POST.get("message")  # Retrieve message from POST data

        # Define API request payload
        payload = {
            "messages": [
                {"role": "system", "content": "You are a test assistant."},
                {"role": "user", "content": user_message},
            ],
            "model": "grok-beta",
            "stream": False,
            "temperature": 0,
        }

        # Define API headers
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {settings.AI_API_KEY}",
        }

        # Make the API request
        try:
            response = requests.post(settings.AI_API_URL, json=payload, headers=headers)
            if response.status_code == 200:
                # Extract the AI's response
                ai_message = response.json().get("choices", [{}])[0].get("message", {}).get("content", "")
                return JsonResponse({"message": ai_message})
            else:
                print(f"API Error: {response.status_code} - {response.text}")
                return JsonResponse({"error": "Failed to communicate with AI API"}, status=500)
        except Exception as e:
            print(f"Exception: {e}")
            return JsonResponse({"error": "An error occurred while processing the request"}, status=500)

    return JsonResponse({"error": "Invalid request method"}, status=400)
