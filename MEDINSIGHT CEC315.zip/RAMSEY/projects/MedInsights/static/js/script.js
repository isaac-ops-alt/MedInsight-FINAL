// Function to send a message to the bot and get a response
function getBotResponse(message) {
    return new Promise((resolve, reject) => {
        fetch('/chat/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-CSRFToken': getCSRFToken(), // CSRF token for security
            },
            body: new URLSearchParams({ message: message }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.message) {
                resolve(data.message); // Bot response
            } else {
                reject("No response received.");
            }
        })
        .catch(error => reject("An error occurred while contacting the server."));
    });
}

// CSRF Token Helper (if Django CSRF is enabled)
function getCSRFToken() {
    const cookies = document.cookie.split(";").map(cookie => cookie.trim());
    for (const cookie of cookies) {
        if (cookie.startsWith("csrftoken=")) {
            return cookie.split("=")[1];
        }
    }
    return "";
}

// Append message to the chat box
function appendMessage(sender, message) {
    const chatBox = document.getElementById("chat-box");
    const messageElement = document.createElement("div");
    messageElement.classList.add("chat-message", `${sender}-message`);
    
    const messageContent = document.createElement("p");
    messageContent.textContent = message;
    messageElement.appendChild(messageContent);
    
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight; // Auto-scroll to the latest message
}

// Handle send button click
document.addEventListener("DOMContentLoaded", () => {
    const send_btn = document.getElementById("send_btn");
    const user_input = document.getElementById("user_input");

    send_btn.addEventListener("click", async () => {
        console.log("Send button clicked!"); // Debug
        const message = user_input.value.trim();
        console.log("User message:", message); // Debug

        if (message) {
            appendMessage("user", message); // Add user message to the chat box
            try {
                const botResponse = await getBotResponse(message); // Get bot response
                console.log("Bot response:", botResponse); // Debug
                appendMessage("bot", botResponse); // Add bot message to the chat box
            } catch (error) {
                console.error("Error:", error); // Debug
                appendMessage("bot", "Sorry, something went wrong."); // Fallback error message
            }
        } else {
            console.log("No message entered."); // Debug
        }
        user_input.value = ""; // Clear input field
    });
});
